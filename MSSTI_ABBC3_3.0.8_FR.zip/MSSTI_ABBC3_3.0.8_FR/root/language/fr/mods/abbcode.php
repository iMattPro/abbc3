<?php
/**
* @package: phpBB3 3.0.8:: Advanced BBCode box 3 -> root/language/fr/mods :: [fr][French]
* @version: $Id: abbcode.php, v 3.0.8 2010/09/29 00:07:22 eric0279 Exp $
* @copyright: leviatan21 < info@mssti.com > (Gabriel) http://www.mssti.com/phpbb3/
* @license: http://opensource.org/licenses/gpl-license.php GNU Public License 
* @author: leviatan21 - http://www.phpbb.com/community/memberlist.php?mode=viewprofile&u=345763
* @translator: VSE - http://www.phpbb.com/community/memberlist.php?mode=viewprofile&u=868795
* @translator: Sylver35 - http://breizh-portal.com
* @translator: Owned - http://www.css-ressource.com/
**/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Reference : http://www.phpbb.com/mods/documentation/phpbb-documentation/language/index.php#lang-use-php
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

$lang = array_merge($lang, array(
// Help page
	'ABBC3_HELP_TITLE'			=> 'Advanced BBCode box 3 : Page d’aide',
	'ABBC3_HELP_DESC'			=> 'Description',
	'ABBC3_HELP_WRITE'			=> 'Votre format d’écriture',
	'ABBC3_HELP_VIEW'			=> 'Notre format d’affichage',
	'ABBC3_HELP_ABOUT'			=> 'Advanced BBCode Box 3 par <a href="http://www.mssti.com/phpbb3">mssti</a> traduction fr: <a href="http://breizh-portal.com">Sylver35</a> et <a href="http://www.css-ressource.com">Owned</a>',
	'ABBC3_HELP_ALT'			=> 'Advanced BBCode Box 3 (aka ABBC3)',

// Image Resizer JS
	'ABBC3_RESIZE_SMALL'		=> 'Cliquez sur cette barre pour voir l’image complète.',
	'ABBC3_RESIZE_ZOOM_IN'		=> 'Agrandir l’image (dimensions réelles : %1$s x %2$s)',
	'ABBC3_RESIZE_CLOSE'		=> 'Fermer',
	'ABBC3_RESIZE_ZOOM_OUT'		=> 'Réduire',
	'ABBC3_RESIZE_FILESIZE'		=> 'Cette image a été redimensionnée. L’image originale a pour taille %1$s x %2$s et pèse %3$sKB.',
	'ABBC3_RESIZE_NOFILESIZE'	=> 'Cette image a été redimensionnée. L’image originale a pour taille %1$s x %2$s.',
	'ABBC3_RESIZE_FULLSIZE'		=> 'Image redimensionnée à: %1$s % de ses dimensions originales [ %2$s x %3$s ]',
	'ABBC3_RESIZE_NUMBER'		=> 'Image %1$s sur %2$s',
	'ABBC3_RESIZE_PLAY'			=> 'Lecture du diaporama',
	'ABBC3_RESIZE_PAUSE'		=> 'Pause du diaporama',
// Pop Box JS
	'ABBC3_POPBOX_REVERSETEXT'	=> 'Cliquez sur l’image pour la rétrécir.',

// Highslide JS - http://vikjavev.no/highslide/forum/viewtopic.php?t=2119
	'ABBC3_HIGHSLIDE_LOADINGTEXT'		=> 'Chargement...',
	'ABBC3_HIGHSLIDE_LOADINGTITLE'		=> 'Cliquez pour annuler',
	'ABBC3_HIGHSLIDE_FOCUSTITLE'		=> 'Cliquez pour placer au premier plan',
	'ABBC3_HIGHSLIDE_FULLEXPANDTITLE'	=> 'Etendre à la taille actuelle',
	'ABBC3_HIGHSLIDE_FULLEXPANDTEXT'	=> 'Pleine taille',
	'ABBC3_HIGHSLIDE_CREDITSTEXT'		=> 'Produit par <i>Highslide JS</i>',
	'ABBC3_HIGHSLIDE_CREDITSTITLE'		=> 'Aller sur la page d’accueil d’Highslide JS',
	'ABBC3_HIGHSLIDE_PREVIOUSTEXT'		=> 'Précédent',
	'ABBC3_HIGHSLIDE_PREVIOUSTITLE'		=> 'Précédent (flèche gauche)',
	'ABBC3_HIGHSLIDE_NEXTTEXT'			=> 'Suivant',
	'ABBC3_HIGHSLIDE_NEXTTITLE'			=> 'Suivant (flèche droite)',
	'ABBC3_HIGHSLIDE_MOVETITLE'			=> 'Déplacer',
	'ABBC3_HIGHSLIDE_MOVETEXT'			=> 'Déplacer',
	'ABBC3_HIGHSLIDE_CLOSETEXT'			=> 'Fermer',
	'ABBC3_HIGHSLIDE_CLOSETITLE'		=> 'Fermer (esc)',
	'ABBC3_HIGHSLIDE_RESIZETITLE'		=> 'Redimensionner',
	'ABBC3_HIGHSLIDE_PLAYTEXT'			=> 'Lecture',
	'ABBC3_HIGHSLIDE_PLAYTITLE'			=> 'Lecture du diaporama (barre espace)',
	'ABBC3_HIGHSLIDE_PAUSETEXT'			=> 'Pause',
	'ABBC3_HIGHSLIDE_PAUSETITLE'		=> 'Pause du diaporama (barre espace)',
	'ABBC3_HIGHSLIDE_NUMBER'			=> 'Image %1 sur %2',
	'ABBC3_HIGHSLIDE_RESTORETITLE'		=> 'Cliquez pour fermer l’image, cliquez et trainez pour déplacer. Utilisez les flèches pour suivant et précédent.',

// Text to be applied to the helpline & mouseover & help page & Wizard texts
	'BBCODE_STYLES_TIP'			=> 'Astuce : Les mises en forme peuvent être rapidement appliquées au texte sélectionné.',
	
	'ABBC3_ERROR'				=> 'Erreur : ',
	'ABBC3_ERROR_TAG'			=> 'Erreur inattendue en utilisant le tag : ',
	'ABBC3_NO_EXAMPLE'         	=> 'Aucun exemple de données',

	'ABBC3_ID'					=> 'Entrez l’identifiant :',
	'ABBC3_NOID'				=> 'Vous n’avez pas saisi l’identifiant',
	'ABBC3_LINK'				=> 'Entrez le lien pour ',
	'ABBC3_DESC'				=> 'Entrez la description pour ',
	'ABBC3_NAME'				=> 'Description',
	'ABBC3_NOLINK'				=> 'Vous n’avez pas entré de lien pour ',
	'ABBC3_NODESC'				=> 'Vous n’avez pas entré de description pour ',
	'ABBC3_WIDTH'				=> 'Entrez la largeur',
	'ABBC3_WIDTH_NOTE'			=> 'Note : La valeur peut être exprimée en pourcentage',
	'ABBC3_NOWIDTH'				=> 'Vous n’avez pas entré de largeur',
	'ABBC3_HEIGHT'				=> 'Entrez la hauteur',
	'ABBC3_HEIGHT_NOTE'			=> 'Note : La valeur peut être exprimée en pourcentage',
	'ABBC3_NOHEIGHT'			=> 'Vous n’avez pas entré de hauteur',

	'ABBC3_NOTE'				=> 'Note',
	'ABBC3_EXAMPLE'				=> 'Exemple',
	'ABBC3_EXAMPLES'			=> 'Exemples',
	'ABBC3_SHORT'				=> 'Sélectionnez le BBcode',
	'ABBC3_DEPRECATED'			=> '<div class="error">The <em>%1$s</em> BBcode has been deprecated as of ABBC3 version <em>%2$s</em></div>',
	'ABBC3_UNAUTHORISED'		=> 'Vous ne pouvez pas utiliser certains mots : <br /><strong> %s </strong>',
	'ABBC3_NOSCRIPT'			=> 'Votre navigateur a désactiver certains script ou ne supporte pas les script coté clients. <em>( JavaScript! )</em>',
	'ABBC3_NOSCRIPT_EXPLAIN'	=> 'La page que vous essayer de voir néccésite un plugin javascript pour de meilleur performance.<br />Si vous avais intentionnelement désactiver javascript veiller le réactiver.',
	'ABBC3_FUNCTION_DISABLED'	=> ' Cette fonction n\'est pas disponible sur ce forum.',
	'ABBC3_AJAX_DISABLED'		=> 'Votre navigateur ne supporte pas AJAX (XMLHttpRequest) et n\'a pas pu traiter cette demande.',
	'ABBC3_SUBMIT'				=> 'Insérer dans le message',
	'ABBC3_SUBMIT_SIG'			=> 'Insérer dans la signature',
	'SAMPLE_TEXT'				=> 'Voici un exemple de texte simple', //	' . $lang['SAMPLE_TEXT'] . '
));


/**
* TRANSLATORS PLEASE NOTE 
*	Several lines have an special note like "##	For translate : " follow for one or more "yes" 
*	These means that you can/have to translate the word under
**/
$lang = array_merge($lang, array(
// bbcodes texts
	// Font Type Dropdown
	'ABBC3_FONT_MOVER'			=> 'Police',
	'ABBC3_FONT_TIP'			=> '[font=Comic Sans MS]Texte[/font]',
	'ABBC3_FONT_NOTE'			=> 'Note : Vous pouvez utiliser vos propres polices',
	'ABBC3_FONT_VIEW'			=> '[font=Comic Sans MS]' . $lang['SAMPLE_TEXT'] . '[/font]',

	// Font family Groups
	'ABBC3_FONT_ABBC3'			=> 'ABBC Box 3',
	'ABBC3_FONT_SAFE'			=> 'Liste libre',
	'ABBC3_FONT_WIN'			=> 'Windows par défaut',

	// Font Size Dropdown
	'ABBC3_FONT_GIANT'			=> 'Géant',
	'ABBC3_SIZE_MOVER'			=> 'Taille',
	'ABBC3_SIZE_TIP'			=> '[size=150]Texte large[/size]',
	'ABBC3_SIZE_NOTE'			=> 'Note : La valeur sera interprétée comme un pourcentage',
	'ABBC3_SIZE_VIEW'			=> '[size=150]' . $lang['SAMPLE_TEXT'] . '[/size]',

	// Highlight Font Color Dropdown
	'ABBC3_HIGHLIGHT_MOVER'		=> 'Texte surligné',
	'ABBC3_HIGHLIGHT_TIP'		=> '[highlight=yellow]Texte[/highlight]',
	'ABBC3_HIGHLIGHT_NOTE'		=> 'Note : Vous pouvez utiliser le HTML (color=#FF0000 ou color=red)',
	'ABBC3_HIGHLIGHT_VIEW'		=> '[highlight=yellow]' . $lang['SAMPLE_TEXT'] . '[/highlight]',

	// Font Color Dropdown
	'ABBC3_COLOR_MOVER'			=> 'Couleur de la police',
	'ABBC3_COLOR_TIP'			=> '[color=red]Texte[/color]',
	'ABBC3_COLOR_NOTE'			=> 'Note : Vous pouvez utiliser le HTML (color=#FF0000 ou color=red)',
	'ABBC3_COLOR_VIEW'			=> '[color=red]' . $lang['SAMPLE_TEXT'] . '[/color]',
	//'ABBC3_COLOR_EXPLAIN'		=> '<strong>Note:</strong> Enable the ABBC3 Font colour menu or disable to use the standard phpBB3 Font colour picker.',
	
	// Tigra Color & Highlight family Groups
	'ABBC3_COLOUR_SAFE'			=> 'Palette Web',
	'ABBC3_COLOUR_WIN'			=> 'Palette système Windows',
	'ABBC3_COLOUR_GREY'			=> 'Palette des gris',
	'ABBC3_COLOUR_MAC'			=> 'Palette Mac OS',
	'ABBC3_SAMPLE'				=> 'échantillon',

	// Cut selected text
	'ABBC3_CUT_MOVER'			=> 'Supprimez le texte sélectionné',
	// Copy selected text
	'ABBC3_COPY_MOVER'			=> 'Copiez le texte sélectionné',
	// Paste previously copy text
	'ABBC3_PASTE_MOVER'			=> 'Collez le texte sélectionné',
	'ABBC3_PASTE_ERROR'			=> 'Vous devez tout d’abord copier un texte, puis le coller',
	// Remove BBCode (Removes all BBCode tags from selected text)
	'ABBC3_PLAIN_MOVER'			=> 'Supprimez les balises bbcodes du texte sélectionné',
	'ABBC3_NOSELECT_ERROR'		=> 'Aucun texte n’a été sélectionné',

	// Code
	'ABBC3_CODE_MOVER'			=> 'Insérer du Code',
	'ABBC3_CODE_TIP'			=> '[code]Code[/code]',
	'ABBC3_CODE_VIEW'			=> '[code]' . $lang['SAMPLE_TEXT'] . '[/code]',

	// Quote
	'ABBC3_QUOTE_MOVER'			=> 'Citer',
	'ABBC3_QUOTE_TIP'			=> '[quote]' . $lang['SAMPLE_TEXT'] . '[/quote] ou [quote=\"membre\"]' . $lang['SAMPLE_TEXT'] . '[/quote]',
##	For translate :                                        yes
	'ABBC3_QUOTE_VIEW'			=> '[quote]' . $lang['SAMPLE_TEXT'] . '[/quote] ou [quote=&quot;membre&quot;]' . $lang['SAMPLE_TEXT'] . '[/quote]',

	// Spoiler
	'ABBC3_SPOIL_MOVER'			=> 'Texte du spoiler',
	'ABBC3_SPOIL_TIP'			=> '[spoil]texte[/spoil]',
	'ABBC3_SPOIL_VIEW'			=> '[spoil]' . $lang['SAMPLE_TEXT'] . '[/spoil]',
	'SPOILER_SHOW'				=> 'Montrer le Spoiler',
	'SPOILER_HIDE'				=> 'Cacher le Spoiler',

	// hidden
	'ABBC3_HIDDEN_MOVER'		=> 'Masquer le contenu pour les invités',
	'ABBC3_HIDDEN_TIP'			=> '[hidden]texte devant être caché aux invités[/hidden]',
	'ABBC3_HIDDEN_VIEW'			=> '[hidden]' . $lang['SAMPLE_TEXT'] . '[/hidden]',
	'HIDDEN_OFF'				=> 'Contenu caché est désactivé',
	'HIDDEN_ON'					=> 'Contenu caché est opérationnel',
	'HIDDEN_EXPLAIN'			=> 'Ce forum requière que vous devez être inscrit et connecté pour pouvoir afficher le message caché',

	// Moderator tag
	'ABBC3_MOD_MOVER'			=> 'Message de Modérateur',
	'ABBC3_MOD_TIP'				=> '[mod=name]texte[/mod]',
##	For translate :                                                                                                                                                                               yes
	'ABBC3_MOD_VIEW'			=> '[mod=Moderator_name]' . $lang['SAMPLE_TEXT'] . '[/mod]',

	// Off topic tag
	'OFFTOPIC'					=> 'Hors-sujet',
	'ABBC3_OFFTOPIC_MOVER'		=> 'Inserez un texte en mode off topic',
	'ABBC3_OFFTOPIC_TIP'		=> '[offtopic]texte[/offtopic]',
	'ABBC3_OFFTOPIC_VIEW'		=> '[offtopic]' . $lang['SAMPLE_TEXT'] . '[/offtopic]',

	// SCRIPPET
	'ABBC3_SCRIPPET_MOVER'		=> "Scrippet",
	'ABBC3_SCRIPPET_TIP'		=> "[scrippet]Texte du Scénario[/scrippet]",
##	For translate :                 don't change the "<br />" and don't join the lines in one !
	'ABBC3_SCRIPPET_VIEW'		=> '[scrippet]EXT. Rome antique - JOUR<br />
	ANTOINE et IPSUM marchent dans une petite rue très fréquentée.<br />
	ANTOINE<br />
	Pensez-vous que dans mille ans, tout le monde se souviendra de nos noms?<br />
	IPSUM<br />
	Not yours. But they’ll know mine. Because I intend to write something so profound that it will be remembered for the ages. Designers in the 20th Century call for Lorem Ipsum whenever they need to fill text blocks.[/scrippet]',

	// Tabs
	'ABBC3_TABS_MOVER'			=> "Onglets",
	'ABBC3_TABS_TIP'			=> "[tabs] [tabs:Titre]Texte de l’onglet[tabs:Un autre]Texte de l’onglet[/tabs]",
##	For translate :                              yes             yes                                                                                                                              yes               Yes
	'ABBC3_TABS_VIEW'			=> "[tabs] [tabs:Titre de l’onglet]&nbsp;Tout le contenu ci-dessous ce code sera inséré à l’intérieur de l’onglet, jusqu'à ce qu’un autre onglet soit déclaré avec: &#91;tabs:XXX&#93;.[tabs:Un autre onglet]&nbsp;Et ainsi de suite .. jusqu’à la fin de la page ou sur option vous pouvez ajouter le code ci-dessous pour mettre fin au dernier onglet et ajouter plus de texte à l’extérieur des onglets: [/tabs]",

	// NFO
	'ABBC3_NFO_TITLE'			=> 'Texte NFO',
	'ABBC3_NFO_MOVER'			=> 'Texte NFO (Meilleur avec Internet Explorer)',
	'ABBC3_NFO_TIP'				=> '[nfo]Texte NFO[/nfo]',
	'ABBC3_NFO_VIEW'			=> '[nfo]		Ü²Ü  Û Û²²     ÛÛÛÛ  Û ÛÛÛÛÛÛÛÛÛÛÛÛÛÛÛÛÛÛÛÛÛÛÛÛÛÛÛÛ     ÛÛÛÛ Û  Û ÛÛÛÛÛ ²² ±[/nfo]',

	// Justify Align
	'ABBC3_ALIGNJUSTIFY_MOVER'	=> 'Texte justifié',
	'ABBC3_ALIGNJUSTIFY_TIP'	=> '[align=justify]' . $lang['SAMPLE_TEXT'] . '[/align]',
##	For translate :                                                 yes          yes
	'ABBC3_ALIGNJUSTIFY_VIEW'	=> '[align=justify]Ceci est <br />un texte simple<br />' . $lang['SAMPLE_TEXT'] . '[/align]',

	// Right Align
	'ABBC3_ALIGNRIGHT_MOVER'	=> 'Texte aligné sur la droite',
	'ABBC3_ALIGNRIGHT_TIP'		=> '[align=right]' . $lang['SAMPLE_TEXT'] . '[/align]',
	'ABBC3_ALIGNRIGHT_VIEW'		=> '[align=right]' . $lang['SAMPLE_TEXT'] . '[/align]',

	// Center Align
	'ABBC3_ALIGNCENTER_MOVER'	=> 'Texte centré',
	'ABBC3_ALIGNCENTER_TIP'		=> '[align=center]' . $lang['SAMPLE_TEXT'] . '[/align]',
	'ABBC3_ALIGNCENTER_VIEW'	=> '[align=center]' . $lang['SAMPLE_TEXT'] . '[/align]',

	// Left Align
	'ABBC3_ALIGNLEFT_MOVER'		=> 'Texte aligné sur la gauche',
	'ABBC3_ALIGNLEFT_TIP'		=> '[align=left]' . $lang['SAMPLE_TEXT'] . '[/align]',
	'ABBC3_ALIGNLEFT_VIEW'		=> '[align=left]' . $lang['SAMPLE_TEXT'] . '[/align]',

	// Preformat
	'ABBC3_PRE_MOVER'			=> 'Texte préformaté',
	'ABBC3_PRE_TIP'				=> '[pre]' . $lang['SAMPLE_TEXT'] . '[/pre]',
	'ABBC3_PRE_VIEW'			=> '[pre]' . $lang['SAMPLE_TEXT'] . '<br />		' . $lang['SAMPLE_TEXT'] . '[/pre]',

	// Tab
	'ABBC3_TAB_MOVER'			=> 'Créez un espace normal',
	'ABBC3_TAB_TIP'				=> '[tab=nn]',
	'ABBC3_TAB_NOTE'			=> 'Entrez un nombre qui sera une marge mesurée en pixels.',
	'ABBC3_TAB_VIEW'			=> '[tab=30]' . $lang['SAMPLE_TEXT'],

	// Superscript
	'ABBC3_SUP_MOVER'			=> 'Texte en exposant',
	'ABBC3_SUP_TIP'				=> '[sup]' . $lang['SAMPLE_TEXT'] . '[/sup]',
##	For translate :                 yes                                                                 yes
	'ABBC3_SUP_VIEW'			=> 'Voici un exemple de texte [sup]' . $lang['SAMPLE_TEXT'] . '[/sup] Voici un texte normal',

	// Subscript
	'ABBC3_SUB_MOVER'			=> 'Texte en indice',
	'ABBC3_SUB_TIP'				=> '[sub]' . $lang['SAMPLE_TEXT'] . '[/sub]',
##	For translate :                 yes                                                                 yes
	'ABBC3_SUB_VIEW'			=> 'Voici un exemple de texte [sub]' . $lang['SAMPLE_TEXT'] . '[/sub] Voici un texte normal',

	// Bold
	'ABBC3_B_MOVER'				=> 'Texte en gras',
	'ABBC3_B_TIP'				=> '[b]' . $lang['SAMPLE_TEXT'] . '[/b]',
	'ABBC3_B_VIEW'				=> '[b]' . $lang['SAMPLE_TEXT'] . '[/b]',

	// Italic
	'ABBC3_I_MOVER'				=> 'Texte en italique',
	'ABBC3_I_TIP'				=> '[i]' . $lang['SAMPLE_TEXT'] . '[/i]',
	'ABBC3_I_VIEW'				=> '[i]' . $lang['SAMPLE_TEXT'] . '[/i]',

	// Underline
	'ABBC3_U_MOVER'				=> 'Texte souligné',
	'ABBC3_U_TIP'				=> '[u]' . $lang['SAMPLE_TEXT'] . '[/u]',
	'ABBC3_U_VIEW'				=> '[u]' . $lang['SAMPLE_TEXT'] . '[/u]',

	// Strikethrough
	'ABBC3_S_MOVER'				=> 'Texte barré',
	'ABBC3_S_TIP'				=> '[s]' . $lang['SAMPLE_TEXT'] . '[/s]',
	'ABBC3_S_VIEW'				=> '[s]' . $lang['SAMPLE_TEXT'] . '[/s]',

	// Text Fade
	'ABBC3_FADE_MOVER'			=> 'Texte en fondu',
	'ABBC3_FADE_TIP'			=> '[fade]' . $lang['SAMPLE_TEXT'] . '[/fade]',
	'ABBC3_FADE_VIEW'			=> '[fade]' . $lang['SAMPLE_TEXT'] . '[/fade]',

	// Text Gradient
	'ABBC3_GRAD_MOVER'			=> 'Texte en arc en ciel',
	'ABBC3_GRAD_TIP'			=> '',
##For translate (The separate words are "This is a sample text") 
##												   yes                     yes                     yes                     yes                      yes                     yes                      yes                      yes                     yes                     yes                     yes                     yes                     yes                      yes                     yes                     yes                     yes
	'ABBC3_GRAD_VIEW'			=> '[color=#FF0000]T[/color][color=#F2000D]h[/color][color=#E6001A]i[/color][color=#D90026]s[/color] [color=#BF0040]i[/color][color=#B3004D]s[/color] [color=#990066]a[/color] [color=#800080]s[/color][color=#73008C]a[/color][color=#660099]m[/color][color=#5900A6]p[/color][color=#4D00B3]l[/color][color=#4000BF]e[/color] [color=#2600D9]t[/color][color=#1A00E6]e[/color][color=#0D00F2]x[/color][color=#0000FF]t[/color]',
	'ABBC3_GRAD_MIN_ERROR'		=> 'Aucun texte n’a été sélectionné.',
	'ABBC3_GRAD_MAX_ERROR'		=> 'Seulement 120 caractères maximum autorisés.',
	'ABBC3_GRAD_COLORS'			=> 'Couleurs pré-sélectionnées',
	'ABBC3_GRAD_ERROR'			=> 'Erreur: ColorCode constructeur a échoué',

	// Glow text
	'ABBC3_GLOW_MOVER'			=> 'Texte avec Glow (Seulement avec Internet Explorer)',
	'ABBC3_GLOW_TIP'			=> '[glow=(color)]' . $lang['SAMPLE_TEXT'] . '[/glow]',
	'ABBC3_GLOW_VIEW'			=> '[glow=red]' . $lang['SAMPLE_TEXT'] . '[/glow]',

	// Shadow text
	'ABBC3_SHADOW_MOVER'		=> 'Texte avec Shadow (Seulement avec Internet Explorer)',
	'ABBC3_SHADOW_TIP'			=> '[shadow=(color)]' . $lang['SAMPLE_TEXT'] . '[/shadow]',
	'ABBC3_SHADOW_VIEW'			=> '[shadow=blue]' . $lang['SAMPLE_TEXT'] . '[/shadow]',

	// Dropshadow text
	'ABBC3_DROPSHADOW_MOVER'	=> 'Texte avec Dropshadow (Seulement avec Internet Explorer)',
	'ABBC3_DROPSHADOW_TIP'		=> '[dropshadow=(color)]' . $lang['SAMPLE_TEXT'] . '[/dropshadow]',
	'ABBC3_DROPSHADOW_VIEW'		=> '[dropshadow=blue]' . $lang['SAMPLE_TEXT'] . '[/dropshadow]',

	// Blur text
	'ABBC3_BLUR_MOVER'			=> 'Texte avec Blur (Seulement avec Internet Explorer)',
	'ABBC3_BLUR_TIP'			=> '[blur=(color)]' . $lang['SAMPLE_TEXT'] . '[/blur]',
	'ABBC3_BLUR_VIEW'			=> '[blur=blue]' . $lang['SAMPLE_TEXT'] . '[/blur]',

	// Wave text
	'ABBC3_WAVE_MOVER'			=> 'Texte en vague (Seulement avec Internet Explorer)',
	'ABBC3_WAVE_TIP'			=> '[wave=(color)]' . $lang['SAMPLE_TEXT'] . '[/wave]',
	'ABBC3_WAVE_VIEW'			=> '[wave=blue]' . $lang['SAMPLE_TEXT'] . '[/wave]',

	// Unordered List
	'ABBC3_LISTB_MOVER'			=> 'Liste à puces',
	'ABBC3_LISTB_TIP'			=> '[list]' . $lang['SAMPLE_TEXT'] . '[/list]',
	'ABBC3_LISTB_NOTE'			=> 'Note : Utilisez [*] pour créer les puces',
##	For translate :                         yes           yes           yes                   yes              yes              yes                yes
	'ABBC3_LISTB_VIEW'			=> '[list][*]Sujet 1[*]Sujet 2[*]Sujet 3[/list] ou [list][*]Sujet 1[list][*]Sous-sujet 1[list][*]Sous-sous-sujet1[/list][/list][/list]',

	// Ordered List
	'ABBC3_LISTO_MOVER'			=> 'Liste ordonnée',
	'ABBC3_LISTO_TIP'			=> '[list=1|a]' . $lang['SAMPLE_TEXT'] . '[/list]',
	'ABBC3_LISTO_NOTE'			=> 'Note: Utilisez [*] pour créer les puces',
##	For translate :                                                                  yes          yes           yes             yes                                                   yes           yes           yes             yes                                                   yes            yes            yes              yes                                                   yes            yes             yes                yes                                                   yes            yes             yes
	'ABBC3_LISTO_VIEW'			=> '[list=1][*]Sujet 1[*]Sujet 2[*]Sujet 3[/list] ou [list=a][*]Sujet a[*]Sujet b[*]Sujet c[/list] ou [list=A][*]Sujet A[*]Sujet B[*]Sujet C[/list] ou [list=i][*]Sujet i[*]Sujet ii[*]Sujet iii[/list] ou [list=I][*]Sujet I[*]Sujet II[*]Sujet III[/list]',

	// List item
	'ABBC3_LISTITEM_MOVER'		=> 'Article en liste',
	'ABBC3_LISTITEM_TIP'		=> '[*]',
	'ABBC3_LISTITEM_NOTE'		=> 'Note : Créez des puces dans la liste',

	// Line Break
	'ABBC3_HR_MOVER'			=> 'Ligne de séparation',
	'ABBC3_HR_TIP'				=> '[hr]',
	'ABBC3_HR_NOTE'				=> 'Note: Créez une ligne pour séparer du texte',
	'ABBC3_HR_VIEW'				=> $lang['SAMPLE_TEXT'] . '[hr]' . $lang['SAMPLE_TEXT'],

	// Message Box text direction right to Left
	'ABBC3_DIRRTL_MOVER'		=> 'Texte se lisant de droite à gauche',
	'ABBC3_DIRRTL_TIP'			=> '[dir=rtl]' . $lang['SAMPLE_TEXT'] . '[/dir]',
	'ABBC3_DIRRTL_VIEW'			=> '[dir=rtl]' . $lang['SAMPLE_TEXT'] . '[/dir]',

	// Message Box text direction Left to right
	'ABBC3_DIRLTR_MOVER'		=> 'Texte se lisant de gauche à droite',
	'ABBC3_DIRLTR_TIP'			=> '[dir=ltr]' . $lang['SAMPLE_TEXT'] . '[/dir]',
	'ABBC3_DIRLTR_VIEW'			=> '[dir=ltr]' . $lang['SAMPLE_TEXT'] . '[/dir]',

	// Marquee Down
	'ABBC3_MARQDOWN_MOVER'		=> 'Texte se déplaçant vers le bas',
	'ABBC3_MARQDOWN_TIP'		=> '[marq=down]' . $lang['SAMPLE_TEXT'] . '[/marq]',
	'ABBC3_MARQDOWN_VIEW'		=> '[marq=down]' . $lang['SAMPLE_TEXT'] . '[/marq]',

	// Marquee Up
	'ABBC3_MARQUP_MOVER'		=> 'Texte se déplaçant vers le haut',
	'ABBC3_MARQUP_TIP'			=> '[marq=up]' . $lang['SAMPLE_TEXT'] . '[/marq]',
	'ABBC3_MARQUP_VIEW'			=> '[marq=up]' . $lang['SAMPLE_TEXT'] . '[/marq]',

	// Marquee Right
	'ABBC3_MARQRIGHT_MOVER'		=> 'Texte se déplaçant vers la droite',
	'ABBC3_MARQRIGHT_TIP'		=> '[marq=right]' . $lang['SAMPLE_TEXT'] . '[/marq]',
	'ABBC3_MARQRIGHT_VIEW'		=> '[marq=right]' . $lang['SAMPLE_TEXT'] . '[/marq]',

	// Marquee Left
	'ABBC3_MARQLEFT_MOVER'		=> 'Texte se déplaçant vers la gauche',
	'ABBC3_MARQLEFT_TIP'		=> '[marq=left]' . $lang['SAMPLE_TEXT'] . '[/marq]',
	'ABBC3_MARQLEFT_VIEW'		=> '[marq=left]' . $lang['SAMPLE_TEXT'] . '[/marq]',

	// Table row cell wizard
	'ABBC3_TABLE_MOVER'			=> 'Insérer un tableau',
	'ABBC3_TABLE_TIP'			=> '[table=(ccs style)][tr=(ccs style)][td=(ccs style)]' . $lang['SAMPLE_TEXT'] . '[/td][/tr][/table]',
	'ABBC3_TABLE_VIEW'			=> '[table=width:50%;border:1px solid #cccccc][tr=text-align:center][td=border:1px solid #cccccc]' . $lang['SAMPLE_TEXT'] . '[/td][/tr][/table]',

	'ABBC3_TABLE_STYLE'			=> 'Entrez les paramètres du tableau',
	'ABBC3_TABLE_EXAMPLE'		=> 'width:50%;border:1px solid #cccccc;',

	'ABBC3_ROW_NUMBER'			=> 'Entrez le nombre de lignes',
	'ABBC3_ROW_ERROR'			=> 'Vous n’avez pas spécifié le nombre de lignes',
	'ABBC3_ROW_STYLE'			=> 'Entrez les paramètres des lignes',
	'ABBC3_ROW_EXAMPLE'			=> 'text-align:center;',

	'ABBC3_CELL_NUMBER'			=> 'Entrez le nombre de colonnes',
	'ABBC3_CELL_ERROR'			=> 'Vous n’avez pas spécifié le nombre de colonnes',
	'ABBC3_CELL_STYLE'			=> 'Entrez les paramètres des colonnes',
	'ABBC3_CELL_EXAMPLE'		=> 'border:1px solid #cccccc;',

	// Anchor
	'ABBC3_ANCHOR_MOVER'		=> "point d’ancrage",
	'ABBC3_ANCHOR_TIP'			=> "[anchor=(nom de ce point d’ancrage) goto=(le nom d’un autre point d’ancrage)]Texte[/anchor]",
	'ABBC3_ANCHOR_EXAMPLE'		=> "[anchor=a1 goto=a2]Aller au point d’ancrage a2[/anchor]",
##	For translate :                                           yes                         Yes               Yes
	'ABBC3_ANCHOR_VIEW'			=> "[anchor=help0 goto=help_1]Aller au point d’ancrage 1[/anchor]<br /> ou  [anchor=help1]ceci est le point d’ancrage 1[/anchor]",

	// Hyperlink Wizard
	'ABBC3_URL_TAG'				=> 'Page',
	'ABBC3_URL_MOVER'			=> 'Insérer une adresse web',	
	'ABBC3_URL_TIP'				=> '[url]http://...[/url] ou [url=http://...]Nom du site Web[/url]',
	'ABBC3_URL_EXAMPLE'			=> 'http://breizh-portal.com',
	'ABBC3_URL_VIEW'			=> '[url=http://breizh-portal.com].:: BREIZH PORTAL ::.[/url]',

	// Email Wizard
	'ABBC3_EMAIL_TAG'			=> 'Email',
	'ABBC3_EMAIL_MOVER'			=> 'Email',
	'ABBC3_EMAIL_TIP'			=> '[email]user@server.ext[/email] ou [email=user@server.ext]Mon email[/email]',
	'ABBC3_EMAIL_EXAMPLE'		=> 'user@server.ext',
	'ABBC3_EMAIL_VIEW'			=> '[email=user@server.ext]user@server.ext[/email]',

	// Ed2k link Wizard
	'ABBC3_ED2K_TAG'			=> 'ed2k',
	'ABBC3_ED2K_MOVER'			=> 'Lien ed2k',
	'ABBC3_ED2K_TIP'			=> '[url]Lien ed2k[/url] ou [url=lien ed2k]Nom ed2k[/url]',
	'ABBC3_ED2K_EXAMPLE'		=> 'ed2k://|file|The_Two_Towers-The_Purist_Edit-Trailer.avi|14997504|965c013e991ee246d63d45ea71954c4d|/',
	'ABBC3_ED2K_VIEW'			=> '[url=ed2k://|file|The_Two_Towers-The_Purist_Edit-Trailer.avi|14997504|965c013e991ee246d63d45ea71954c4d|/]The_Two_Towers-The_Purist_Edit-Trailer.avi[/url]',
	'ABBC3_ED2K_ADD'			=> 'Ajoutez les liens sélectionnés à votre client ed2k',
	'ABBC3_ED2K_FRIEND'			=> 'Ami ed2k',
	'ABBC3_ED2K_SERVER'			=> 'Serveur ed2k',
	'ABBC3_ED2K_SERVERLIST'		=> 'Liste de serveurs ed2k',

	// Web included by iframe
	'ABBC3_WEB_TAG'				=> 'Lien web',
	'ABBC3_WEB_MOVER'			=> 'Insérez un site web (iframe) dans le post',
	'ABBC3_WEB_TIP'				=> '[web width=200 height=100]Lien web[/web]',
	'ABBC3_WEB_EXAMPLE'			=> 'http://breizh-portal.com',
	'ABBC3_WEB_VIEW'			=> '[web width=99% height=140]http://breizh-portal.com[/web]',
	'ABBC3_WEB_EXPLAIN'			=> '<strong class="error">Note:</strong> permettre d\'insérer des sites Web dans les messages, cela comporte un risque pour la sécurité. A utiliser à vos risques et périls, ou céder à des groupes de confiance.',

	// Image & Thumbnail Wizard
	'ABBC3_ALIGN_MODE'			=> 'Align image',
##	For translate :							 Don't				Yes
	'ABBC3_ALIGN_SELECTOR'		=> array(	'none'			=> 'Defaut',
											'left'			=> 'Gauche',
											'center'		=> 'Centre',
											'right'			=> 'Droite',
											'float-left'	=> 'Gauche Flottant',
											'float-right'	=> 'Droit Flottant'),

	// Image
	'ABBC3_IMG_TAG'				=> 'Image',
	'ABBC3_IMG_MOVER'			=> 'Insérez une image',
	'ABBC3_IMG_TIP'				=> '[img=(left|center|right)]http://...[/img]',
	'ABBC3_IMG_EXAMPLE'			=> 'http://www.google.com/intl/en_com/images/logo_plain.png',
	'ABBC3_IMG_VIEW'			=> '[img=center]http://www.google.com/intl/en_com/images/logo_plain.png[/img]',

	// Thumbnail
	'ABBC3_THUMBNAIL_TAG'		=> 'Image Thumbnail',
	'ABBC3_THUMBNAIL_MOVER'		=> 'Insérez une image miniature',
	'ABBC3_THUMBNAIL_TIP'		=> '[thumbnail(=left|right)]http://...[/thumbnail]',
	'ABBC3_THUMBNAIL_EXAMPLE'	=> 'http://www.google.com/intl/en_com/images/logo_plain.png',
	'ABBC3_THUMBNAIL_VIEW'		=> '[thumbnail]http://www.google.com/intl/en_com/images/logo_plain.png[/thumbnail]',

	// Imgshack
	'ABBC3_IMGSHACK_MOVER'		=> 'Insérez une image de Imageshack',
	'ABBC3_IMGSHACK_TIP'		=> '[url=http://imageshack.us][img=http://...][/img][/url]',
	'ABBC3_IMGSHACK_VIEW'		=> '[url=http://img22.imageshack.us/my.php?image=abbc3v1012newscreen.gif][img]http://img22.imageshack.us/img22/6241/abbc3v1012newscreen.th.gif[/img][/url]',

	// Rapid share checker
	'ABBC3_FOPEN_ERROR'			=> '<strong>Erreur : </strong>Il semble que <strong>l’allow_url_fopen</strong> soit désactivé. Cette fonction requiert l’activation de la directive PHP allow_url_fopen.',
	'ABBC3_RAPIDSHARE_TAG'		=> 'Rapidshare',
	'ABBC3_RAPIDSHARE_MOVER'	=> 'Insérez un fichier de Rapidshare',
	'ABBC3_RAPIDSHARE_TIP'		=> '[rapidshare]http://rapidshare.com/files/...[/rapidshare]',
	'ABBC3_RAPIDSHARE_EXAMPLE'	=> 'http://rapidshare.com/files/86587996/MSSTI_ABBC3_v1011.zip.html',
	'ABBC3_RAPIDSHARE_VIEW'		=> '[rapidshare]http://rapidshare.com/files/86587996/ABBC3_v1012.zip.html[/rapidshare]',
	'ABBC3_RAPIDSHARE_GOOD'		=> 'Fichier trouvé sur le serveur !',
	'ABBC3_RAPIDSHARE_WRONG'	=> 'Fichier non trouvé sur le serveur !',

	// testlink
	'ABBC3_CURL_ERROR'			=> '<strong>Erreur : </strong>Il semble que CURL ne soit pas activé. Veuillez l’installer pour utiliser cette fonction.',	
	'ABBC3_LOGIN_EXPLAIN_VIEW'	=> 'Ce forum requière que vous soyez enregistré et connecté pour voir les liens.',
	'ABBC3_TESTLINK_TAG'		=> 'Vérificateur de liens',
	'ABBC3_TESTLINK_MOVER'		=> 'Insérez un fichier stocké sur un serveur public',
	'ABBC3_TESTLINK_TIP'		=> '[testlink]http://rapidshare.com/files/...[/testlink]',
	'ABBC3_TESTLINK_NOTE'		=> 'Valid servers:rapidshare,megaupload,megarotic,depositfiles,megashares .',
	'ABBC3_TESTLINK_EXAMPLE'	=> 'http://rapidshare.com/files/86587996/ABBC3_v108.zip.html',
	'ABBC3_TESTLINK_VIEW'		=> '[testlink]http://rapidshare.com/files/86587996/ABBC3_v1012.zip.html[/testlink]',
	'ABBC3_TESTLINK_GOOD'		=> 'Fichier trouvé sur le serveur !',
	'ABBC3_TESTLINK_WRONG'		=> 'Fichier non trouvé !',

	// Click counter
	'ABBC3_CLICK_TAG'			=> 'Clic',
	'ABBC3_CLICK_MOVER'			=> 'Insérez un compteur de clics',
	'ABBC3_CLICK_TIP'			=> '[click]http://...[/click] ou [click=http://...]Nom du site Web[/click] ou [click][img]http://...[/img][/click]',
	'ABBC3_CLICK_EXAMPLE' 		=> 'http://www.google.com ' . ' ' . 'http://www.google.com/intl/en_com/images/logo_plain.png' ,
##	For translate :                                                                     yes
	'ABBC3_CLICK_VIEW'			=> '[click=http://www.mssti.com] .:: MSSTI ::. [/click] ou [click]http://www.google.com/intl/en_com/images/logo_plain.png[/click]',
	'ABBC3_CLICK_TIME'			=> '( Cliqué %d fois )',
	'ABBC3_CLICK_TIMES'			=> '( Cliqué %d fois )',
	'ABBC3_CLICK_ERROR'			=> '<strong>ERREUR :</strong> Veuillez entrer une ID valide dans l’URL',

	// Search tag
	'ABBC3_SEARCH_MOVER'		=> 'Insérez une recherche de mot',
	'ABBC3_SEARCH_TIP'			=> '[search(=(msn|yahoo|google|altavista|lycos|wikipedia))]Texte[/search]',
##	For translate :                                                              yes                                                 yes                                                   yes                                                    yes                                                       yes                                                   yes
	'ABBC3_SEARCH_VIEW'			=> '[search]Advanced BBcode Box 3[/search]<br /> ou [search=msn]Advanced BBcode Box 3[/search]<br /> ou [search=yahoo]Advanced BBcode Box 3[/search]<br /> or [search=google]Advanced BBcode Box 3[/search]<br /> ou [search=altavista]Advanced BBcode Box 3[/search]<br /> ou [search=lycos]Advanced BBcode Box 3[/search]<br /> or [search=wikipedia]Advanced BBcode Box 3[/search]',

	// BBvideo Wizard
	'ABBC3_BBVIDEO_TAG'			=> 'BBvidéo',
	'ABBC3_BBVIDEO_MOVER'		=> 'Insérez une vidéo du web',
	'ABBC3_BBVIDEO_TIP'			=> '[BBvideo]URL vidéo[/BBvideo]',
	'ABBC3_BBVIDEO_EXAMPLE'		=> 'http://www.youtube.com/watch?v=TA4hm97m494',
	'ABBC3_BBVIDEO_VIEW'		=> '<object width="200" height="100"><param name="movie" value="http://www.youtube.com/v/TA4hm97m494" /><param name="wmode" value="transparent" /><embed src="http://www.youtube.com/v/TA4hm97m494" type="application/x-shockwave-flash" wmode="transparent" width="200" height="100"></embed></object>',
	'ABBC3_BBVIDEO_SELECT'		=> 'Sélectionnez le type de vidéo',
	'ABBC3_BBVIDEO_SELECT_ERROR'=> 'Cette option est désactivé. Veuillez contacter l\'administrateur %sBoard Administrator% sur ce problème. <br /> En attendant, vous pouvez poster vos liens vidéo en utilisant le BBcode URL standard.',
	'ABBC3_BBVIDEO_FILE'		=> 'Format du fichier',
	'ABBC3_BBVIDEO_VIDEO'		=> 'Video de',
	'ABBC3_BBVIDEO_EXTERNAL'	=> 'Vidéo externe de',

	// Flash (swf) Wizard
	'ABBC3_FLASH_TAG'			=> 'Flash',
	'ABBC3_FLASH_MOVER'			=> 'Insérez un fichier flash (swf)',
	'ABBC3_FLASH_TIP'			=> '[flash width=# height=#]URL flash[/flash] or [flash width,height]URL flash[/flash]',
	'ABBC3_FLASH_EXAMPLE'		=> 'http://www.adobe.com/support/flash/ts/documents/test_version/version.swf',
	'ABBC3_FLASH_VIEW'			=> '[flash 250,200]http://www.adobe.com/support/flash/ts/documents/test_version/version.swf[/flash]',

	// Flash (flv) Wizard
	'ABBC3_FLV_TAG'				=> 'Flash',
	'ABBC3_FLV_MOVER'			=> 'Insérez une vidéo flash (flv)',
	'ABBC3_FLV_TIP'				=> '[flv width=# height=#]URL flash video[/flv] or [flv width,height]URL flash video[/flv]',
	'ABBC3_FLV_EXAMPLE'			=> 'http://www.channel-ai.com/video/eyn/demo1.flv',
	'ABBC3_FLV_VIEW'			=> '[flv 250,200]http://www.channel-ai.com/video/eyn/demo1.flv[/flv]',

	// Streaming Video Wizard
	'ABBC3_VIDEO_TAG'			=> 'Vidéo',
	'ABBC3_VIDEO_MOVER'			=> 'Insérez une vidéo',
	'ABBC3_VIDEO_TIP'			=> '[video width=# height=#]URL video[/video]',
	'ABBC3_VIDEO_EXAMPLE'		=> 'http://www.sarahsnotecards.com/catalunyalive/fishstore.wmv',
	'ABBC3_VIDEO_VIEW'			=> '[video 250,200]http://www.sarahsnotecards.com/catalunyalive/fishstore.wmv[/video]',

	// Streaming Audio Wizard
	'ABBC3_STREAM_TAG'			=> 'Son',
	'ABBC3_STREAM_MOVER'		=> 'Insérez un son',
	'ABBC3_STREAM_TIP'			=> '[stream]URL stream[/stream]',
	'ABBC3_STREAM_EXAMPLE'		=> 'http://realdev1.realise.com/rossa/mov/demo.mp3',
	'ABBC3_STREAM_VIEW'			=> '[stream]http://realdev1.realise.com/rossa/mov/demo.mp3[/stream]',

	// Quick time
	'ABBC3_QUICKTIME_TAG'		=> 'QuickTime',
	'ABBC3_QUICKTIME_MOVER'		=> 'Insérez un fichier QuickTime',
	'ABBC3_QUICKTIME_TIP'		=> '[quicktime width=# height=#]URL fichier QuickTime[/quicktime]',
	'ABBC3_QUICKTIME_EXAMPLE'	=> 'http://www.nature.com/neuro/journal/v3/n3/extref/Li_control.mov.qt' . ' ' . 'http://www.carnivalmidways.com/images/Music/thisisatest.mp3',
	'ABBC3_QUICKTIME_VIEW'		=> '[quicktime width=250 height=200]http://www.nature.com/neuro/journal/v3/n3/extref/Li_control.mov.qt[/quicktime]',

	// Real Media Wizard
	'ABBC3_RAM_TAG'				=> 'Real Media',
	'ABBC3_RAM_MOVER'			=> 'Insérez un fichier Real Media',
	'ABBC3_RAM_TIP'				=> '[ram]URL Real Media[/ram]',
	'ABBC3_RAM_EXAMPLE'			=> 'http://www.bbc.co.uk/scotland/radioscotland/media/radioscotland.ram',
	'ABBC3_RAM_VIEW'			=> '[ram]http://www.bbc.co.uk/scotland/radioscotland/media/radioscotland.ram[/ram]',

	// Google video Wizard
	'ABBC3_GVIDEO_TAG'			=> 'Vidéo Google',
	'ABBC3_GVIDEO_MOVER'		=> 'Insérez une vidéo de Google',
	'ABBC3_GVIDEO_TIP'			=> '[GVideo]URL vidéo[/GVideo]',
	'ABBC3_GVIDEO_EXAMPLE'		=> 'http://video.google.com/videoplay?docid=-8351924403384451128',
	'ABBC3_GVIDEO_VIEW'			=> '[GVideo]http://video.google.com/videoplay?docid=-8351924403384451128[/GVideo]',

	// Youtube video Wizard
	'ABBC3_YOUTUBE_TAG'			=> 'Vidéo Youtube',
	'ABBC3_YOUTUBE_MOVER'		=> 'Insérez une vidéo de Youtube',
	'ABBC3_YOUTUBE_TIP'			=> '[youtube]URL vidéo[/youtube]',
	'ABBC3_YOUTUBE_EXAMPLE'		=> 'http://www.youtube.com/watch?v=TA4hm97m494',
	'ABBC3_YOUTUBE_VIEW'		=> '[youtube]http://www.youtube.com/watch?v=PDGxfsf-xwQ[/youtube]',

	// Veoh video
	'ABBC3_VEOH_TAG'			=> 'Veoh',
	'ABBC3_VEOH_MOVER'			=> 'Insérez une vidéo de Veoh',
	'ABBC3_VEOH_TIP'			=> '[veoh]URL vidéo[/veoh]',
	'ABBC3_VEOH_EXAMPLE'		=> 'http://www.veoh.com/videos/v1409404EqT5SJjM',
	'ABBC3_VEOH_VIEW'			=> '[veoh]http://www.veoh.com/videos/v1409404EqT5SJjM[/veoh]',

	// Collegehumor video
	'ABBC3_COLLEGEHOMOR_TAG'	=> 'Collegehumor',
	'ABBC3_COLLEGEHUMOR_MOVER'	=> 'Insérez une vidéo de Collegehumor',
	'ABBC3_COLLEGEHUMOR_TIP'	=> '[collegehumor]URL vidéo[/collegehumor]',
	'ABBC3_COLLEGEHUMOR_EXAMPLE'=> 'http://www.collegehumor.com/video:1802097',
	'ABBC3_COLLEGEHUMOR_VIEW'	=> '[collegehumor]http://www.collegehumor.com/video:1802097[/collegehumor]',

	// Dailymotion video
	'ABBC3_DM_MOVER'			=> 'Insérez une vidéo de Dailymotion', // from http://www.dailymotion.com/
	'ABBC3_DM_TIP'				=> '[dm]URL vidéo[/dm]',
	'ABBC3_DM_EXAMPLE'			=> 'http://www.dailymotion.com/swf/x3hm7o',
	'ABBC3_DM_VIEW'				=> '[dm]http://www.dailymotion.com/swf/x3hm7o[/dm]',

	// Gamespot video
	'ABBC3_GAMESPOT_MOVER'		=> 'Insérez une vidéo de Gamespot',
	'ABBC3_GAMESPOT_TIP'		=> '[gamespot]URL vidéo[gamespot]',
	'ABBC3_GAMESPOT_EXAMPLE'	=> 'http://www.gamespot.com/video/944074/6185798/tom-clancys-rainbow-six-vegas-2-official-trailer-3',
	'ABBC3_GAMESPOT_VIEW'		=> '[gamespot]http://www.gamespot.com/video/944074/6185798/tom-clancys-rainbow-six-vegas-2-official-trailer-3[gamespot]',

	// Gametrailers video
	'ABBC3_GAMETRAILERS_MOVER'	=> 'Insérez une vidéo de Gametrailers',
	'ABBC3_GAMETRAILERS_TIP'	=> '[gametrailers]URL vidéo[/gametrailers]',
	'ABBC3_GAMETRAILERS_EXAMPLE'=> 'http://www.gametrailers.com/player/30461.html',
	'ABBC3_GAMETRAILERS_VIEW'	=> '[gametrailers]http://www.gametrailers.com/player/30461.html[/gametrailers]',

	// IGN video
	'ABBC3_IGNVIDEO_MOVER'		=> 'Insérez une vidéo d’Ign',
	'ABBC3_IGNVIDEO_TIP'		=> '[ignvideo]URL vidéo[/ignvideo]',
	'ABBC3_IGNVIDEO_EXAMPLE'	=> 'object_ID=967025&downloadURL=http://tvmovies.ign.com/tv/video/article/850/850894/knightrider_trailer_020808_flvlow.flv',
	'ABBC3_IGNVIDEO_VIEW'		=> '[ignvideo]object_ID=967025&downloadURL=http://tvmovies.ign.com/tv/video/article/850/850894/knightrider_trailer_020808_flvlow.flv[/ignvideo]',

	// LiveLeak video
	'ABBC3_LIVELEAK_MOVER'		=> 'Insérez vidéo de Liveleak',
	'ABBC3_LIVELEAK_TIP'		=> '[liveleak]URL vidéo[/liveleak]',
	'ABBC3_LIVELEAK_EXAMPLE'	=> 'http://www.liveleak.com/view?i=413_1202590393',
	'ABBC3_LIVELEAK_VIEW'		=> '[liveleak]http://www.liveleak.com/view?i=413_1202590393[/liveleak]',

	// Custom BBcodes
	// Deezer audio
	'DEEZER_TAG'			=> 'Deezer',
	'DEEZER_MOVER'			=> 'Insérez une musique de Deezer',
	'DEEZER_TIP'			=> '[Deezer]URL Permalien[/Deezer]',
	'DEEZER_EXAMPLE'		=> 'http://www.deezer.com/track/351534',
	'DEEZER_VIEW'			=> '[Deezer]http://www.deezer.com/track/351534[/Deezer]',

));

?>