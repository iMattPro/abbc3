<?php
/**
* @package: phpBB 3.0.8 :: Advanced BBCode box 3 -> root/language/en/mods :: [en][English]
* @version: $Id: acp_abbcode.php, v 3.0.8 2010/09/30 13:03:00 Owned Exp $
* @copyright: leviatan21 < info@mssti.com > (Gabriel) http://www.mssti.com/phpbb3/
* @license: http://opensource.org/licenses/gpl-license.php GNU Public License 
* @author: leviatan21 - http://www.phpbb.com/community/memberlist.php?mode=viewprofile&u=345763
* @translator: Sylver35 - http://breizh-portal.com
* @translator: Owned - http://www.css-ressource.com/
* @translator: VSE - http://www.phpbb.com/community/memberlist.php?mode=viewprofile&u=868795
**/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Reference : http://www.phpbb.com/mods/documentation/phpbb-documentation/language/index.php#lang-use-php
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

// This lines are the same as root/language/en/acp/common.php
$lang = array_merge($lang, array(
	'ACP_ABBCODES'				=> 'BBcodes Box 3 Avancé',
	'ACP_ABBC3_SETTINGS'		=> 'Paramètres ABBC3',
	'ACP_ABBC3_BBCODES'			=> 'ABBC3 BBCodes',
	'LOG_CONFIG_ABBCODES'		=> '<strong>Paramètres ABBC3 modifiés</strong>',
	'LOG_CONFIG_ABBCODES_ERROR'	=> '<strong>Erreur lors de la sauvegarde des paramètres ABBC3</strong>',
));

// This lines are for the UCP
$lang = array_merge($lang, array(
	'UCP_ABBCODES'					=> 'BBcodes Box 3 Avancé',
	'UCP_ABBC3_SETTINGS'			=> 'Paramètres ABBC3',
	'UCP_ABBC3_SETTINGS_EXPLAIN'	=> 'Activer la barre d\'outis de <strong>BBcodes Box 3 Avancé</strong> au-lieu des BBcode standards ?',
	'UCP_ABBC3_BBCODES'				=> 'Voir ABBC3',
	'UCP_ABBC3_BBCODES_EXPLAIN'		=> 'Si la barre d\'outis de <strong>BBcodes Box 3 Avancé</strong> est activé, voulez-vous d\'utiliser la vue Compact au-lieu des boutons ABBC3 ?',
));

// abbc3_details
$lang = array_merge($lang, array(
	'ABBCODES_DISABLE'					=> 'Désactiver ABBC3',
	'ABBCODES_DISABLE_EXPLAIN'			=> 'Activer ou désactiver <strong>BBcodes Box 3 Avancé</strong> pour les membres et/ou utiliser les BBcodes standards de phpBB3.',
	'ABBCODES_PATH'						=> 'Chemin du Script',
	'ABBCODES_PATH_EXPLAIN'				=> 'Chemin d’accès aux fichiers ABBC3 depuis votre répertoire racine de phpBB, ex. <samp>styles/abbcode</samp>',
	'ABBCODES_BG'						=> 'Image de fond',
	'ABBCODES_BG_EXPLAIN'				=> 'Cette option permet de mettre une image de fond pour les icones.<br/>Laissez sur <em>aucune image</em> pour ajuster votre style.',
	'ABBCODES_TAB'						=> 'Afficher les séparations d’icones',
	'ABBCODES_BOXRESIZE'				=> 'Redimensionner la zone du posting',
	'ABBCODES_BOXRESIZE_EXPLAIN'		=> 'Affiche des boutons pour redimensionner la zone du posting.',

	'ABBCODES_RESIZER'					=> 'Redimensionnement des Images',
	'ABBCODES_RESIZE'					=> 'Réduire les grosses images',
	'ABBCODES_RESIZE_EXPLAIN'			=> 'Fix pour un éventuel bug du BBcode [img] si une image postée est plus large que la zone de post.',
	'ABBCODES_JAVASCRIPT_EXPLAIN'		=> '<strong>Note : </strong> <em>AdvancedBox JS</em> est un programme JavaScript utilisé pour afficher les images en pleine taille.<br />Dans le dossier <em>contrib</em>, vous trouverez comment utiliser <strong>ABBC3</strong> avec Highslide JS | LiteBox | GreyBox.<br />Ces modifications sont totalement optionnelles. Chaque script a son propre support.<br />Malheureusement, Internet Explorer ne semble pas comprendre comment gérer les images attachées avec ces programmes.',
	'ABBCODES_RESIZE_METHOD'			=> 'Méthode de redimensionnement',
	'ABBCODES_RESIZE_METHOD_EXPLAIN'	=> 'Choisissez comment afficher l’image redimensionnée en pleine taille.',
	'ABBCODES_RESIZE_BAR'				=> 'Annotation du redimensionnement',
	'ABBCODES_RESIZE_BAR_EXPLAIN'		=> 'Utilisez la barre en haut pour les images redimensionnées',
##	For translate :                                Don't            Yes               Don't        Yes             Don't        Yes        Don't           yes            Don't          yes           Don't     yes
	'ABBCODES_RESIZE_METHODS'			=> array( 	'AdvancedBox' 	=> 'AdvancedBox JS',
													'HighslideBox'	=> 'Highslide Box JS', 
													'LiteBox'		=> 'Lite Box JS', 
													'GreyBox'		=> 'Grey Box JS', 
													'Lightview'		=> 'Light view JS', 
													'Ibox'			=> 'Shadow box avec Ibox JS', 
													'PopBox'		=> 'Pop Box JS', 
													'pop-up' 		=> 'Fenêtre en pop-up', 
													'enlarge' 		=> 'Agrandir', 
													'samewindow' 	=> 'Même fenêtre', 
													'newwindow' 	=> 'Nouvelle fenêtre', 
													'none'			=> 'Aucun redimensionnement'),

	'NO_EXIST_EXPLAIN_ADVANCEDBOX'		=> 'Le fichier <strong>AdvancedBox.js</strong> ne se trouve pas dans le dossier <em>%1$s</em>',
	'NO_EXIST_EXPLAIN_OTHERS'			=> 'Le fichier <strong>%1$s version %2$s</strong>, ne se trouve pas dans le dossier <em>%3$s</em><br />Si vous souhaitez utiliser %4$s, vous devez tout d’abord télécharger le fichier %4$s depuis <a href="%5$s" onclick="window.open(this.href);return false;">here</a> et uploader les fichiers dans le répertoire <em>%3$s</em>.',

	'ABBCODES_MAX_IMAGE_WIDTH'        	=> 'Largeur maximale de l’image en pixels',
	'ABBCODES_MAX_IMAGE_WIDTH_EXPLAIN'  => 'L’image sera automatiquement réduite si elle excède la largeur définie.',
	'ABBCODES_MAX_IMAGE_HEIGHT'         => 'Hauteur maximale de l’image en pixels',
	'ABBCODES_MAX_IMAGE_HEIGHT_EXPLAIN' => 'L’image sera automatiquement réduite si elle excède la hauteur définie.',
	'ABBCODES_MAX_THUMB_WIDTH'			=> 'Largeur maximale de la miniature en pixels',
	'ABBCODES_MAX_THUMB_WIDTH_EXPLAIN'	=> 'La miniature sera automatiquement réduite à la taille définie si elle l’excède.',
	'ABBCODES_RESIZE_SIGNATURE'			=> 'Redimensionner les images trop grosses dans les signatures',
	'ABBCODES_RESIZE_SIGNATURE_EXPLAIN'	=> 'Redimensionner aussi les images trop grosses dans les signatures ?',
	'ABBCODES_SIG_IMAGE_WIDTH'			=> 'Largeur maximale des images dans les signatures en pixels',
	'ABBCODES_SIG_IMAGE_WIDTH_EXPLAIN'	=> 'Les images des signatures seront redimmensionnées si elle exèdent la largeur définie ici.',
	'ABBCODES_SIG_IMAGE_HEIGHT'			=> 'Hauteur maximale des images dans les signatures en pixels',
	'ABBCODES_SIG_IMAGE_HEIGHT_EXPLAIN'	=> 'Les images des signatures seront redimmensionnées si elle exèdent la hauteur définie ici.',

	'ABBCODES_VIDEO_SIZE'				=> 'Dimensions vidéo',
	'ABBCODES_VIDEO_SIZE_EXPLAIN'		=> 'Largeur et hauteur par défaut pour les vidéos postées.',
	'ABBCODES_VIDEO_ALLOWED'			=> 'Types de vidéos autorisées',
	'ABBCODES_VIDEO_ALLOWED_EXPLAIN'	=> 'Sélectionnez les sites vidéo et/ou des formats que vous voulez autoriser pour les utilisateurs à intégrer dans leurs messages lorsque le BBcode BBvideo est activée <em class="error">(*)</em>',
	'ABBCODES_VIDEO_ALLOWED_NOTE'    => '<em class="error">(*)</em> Afin de sélectionner (ou désélectionner) plusieurs articles, vous devez utilisez la touche CTRL + clique gauche de la souris (ou Cmd-clic sur Mac) pour ajouter les éléments . Si vous oubliez de maintenir la touche CTRL/CMD en cliquant sur un élément, tous les éléments précédemment sélectionnés seront désélectionnés.',

	'ABBCODES_COLOUR_MODE'				=> 'Choisi le mode de sélection de couleur',
##	For translate :                                	 Don't			Yes
	'ABBCODES_COLOUR_SELECTOR'			=> array(	'phpbb'		=> 'Thème phpBB par Défaut',
													'dropdown'	=> 'Menu déroulant',
													'fancy'		=> 'Sélecteur de “Fantaisie”',
													'tigra'		=> 'Sélecteur de couleur Tigra'),
	'ABBCODES_WIZARD_MODE'				=> 'Choisi l\'assistant',
##	For translate :                                	Don't			Yes
	'ABBCODES_WIZARD_SELECTOR'			=> array(	'0'			=> 'Désactiver l\'assistant',
													'1'			=> 'Fenêtre Windows',
													'2'			=> 'dans le post'),
	'ABBCODES_UCP_MODE'					=> 'Les options de commande UCP',
	'ABBCODES_UCP_MODE_EXPLAIN'			=> 'Autoriser les utilisateurs à choisir leur propre mode, en choisissant entre les boutons BBcode standard et ceux de ABBC3 "étendue" ou ABBC3 "Compact".',

	'ABBCODES_WIZARD'					=> 'Assistant',
	'ABBCODES_WIZARD_SIZE'				=> 'Dimensions de l\'Assistant',
	'ABBCODES_WIZARD_SIZE_EXPLAIN'		=> 'Largeur et la hauteur  par défaut de la fenêtre de l\'assistant dans une fenêtre pop-up.',

	'ABBCODES_DESELECT_ALL'				=> 'Tout Déselectionner',
	'ABBCODES_SELECT_ALL'				=> 'Tout sélectionner',
));

// bbcodes_edit
$lang = array_merge($lang, array(
	'ABBCODES_SETINGS'					=> 'Paramètres ABBC3',
	'ABBCODES_SETINGS_EXPLAIN'			=> 'Vous pouvez configurer ici les opérations basiques de <strong>ABBC3</strong>, activer ou désactiver, et parmi d’autres paramètres, ajuster la valeur par défaut de votre image de fond.',

	'ABBCODES_EDIT'						=> 'Edition bbcodes ABBC3',
	'ABBCODES_EDIT_EXPLAIN'				=> 'Vous pouvez déterminer ici où le bbcode sera affiché, qui pourra l’utiliser et choisir l’image de chaque bbcode.',

	'ABBCODES_CONFIG'					=> 'Configuration des éléments d’ABBC3',
	'ABBCODES_CONFIG_EXPLAIN'			=> 'A partir de cette page, vous pouvez changer l’ordre des BBcodes sur la page de post ou éditer les icones.',
	'ABBCODES_GROUPS_EXPLAIN'			=> '<strong>Gérer les groupes : </strong>Si aucun groupe n’est sélectionné, tous les membres peuvent se servir de ce bbcode.<br />Pour sélectionner (ou dé-sélectionner) plusieurs groupes, utilisez les touches CTRL et CLIC. Si vous noubliez de maintenir appuyée la touche CTRL, tout ce qui aura alors été sélectionné auparavant sera perdu.',

	'ABBCODES_TIP'						=> 'Tag tip',
	'ABBCODES_NAME'						=> 'Nom du BBcode',
	'ABBCODES_TAG'						=> 'Icone du BBcode',
	'ABBCODES_ORDER'					=> 'Ordre du BBcode',
	'ABBCODES_CUSTOM'					=> 'Personnaliser les BBcode',

	'ABBCODES_BREAK_MOVER'				=> '<strong><i>Ligne de séparation</i></strong>',
	'ABBCODES_DIVISION_MOVER'			=> '<strong><i>Division</i></strong>',
	'ABBCODES_ADD_DIVISION'				=> 'Ajouter une nouvelle division',
	'ABBCODES_ADD_BREAK'				=> 'Ajouter une nouvelle ligne de séparation',
	'ABBCODES_SYNC'						=> 'Resynchronisation de l’ordre',
	'ABBCODES_RESYNC_SUCCESS'			=> 'L’ordre des bbcodes a été resynchronisé.',

	'ABBCODES_MOD_DISABLE'				=> '<strong>BBcodes Box 3 Avancé</strong> est désactivé.<br />',
	'ABBCODES_STATUS'					=> 'Statut',
	'ABBCODES_ACTIVATED'				=> 'Activé',
	'ABBCODES_DEACTIVATED'				=> 'Désactivé',
));

// UMIL Installer 
$lang = array_merge($lang, array(
// Main
	'INSTALLER_TITLE'					=> 'BBcodes Box 3 Avancé',
	'INSTALLER_TITLE_EXPLAIN'			=> 'Bienvenue au menu d\'installation du Mod <strong>BBcodes Box 3 Avancé</strong>',

	'INSTALLER_INSTALL_WELCOME'			=> 'Lorsque vous choisissez d\'installer ABBC3, toutes les données des versions précédentes seront supprimées.',
	'INSTALLER_INSTALL_WELCOME_NOTE'	=> 'Veuillez noter que certains BBCodes pourrait <strong>ne pas</strong> s\'afficher correctement en raison des changements introduits dans BBCodes.
<br /> Si vous rencontrez des problèmes, veuillez utilisez le Mod <a href="http://www.phpbb.com/support/stk/"title="" onclick="window.open(this.href);return false;">Support Toolkit <em>(STK)</em></a> <strong> Outis d\'administration qui Reparse les fonctionnalitées du BBCode</strong>.
<br /> <br /> Avant d\'ajouter ce MOD, nous vous recommandons de faire une sauvegarde complète des fichier et de la base de donnée.',
	'INSTALLER_INSTALL_END'				=> 'Installation de la <strong>version %1$s : %2$s</strong> réussie. <br /> <p>Vous pouvez à présent <a href="../index.php">vous connecter à votre forum</a> et vous assurer que tout fonctionne bien. <br />N’oubliez pas de supprimer le dossier <strong>install_abbc3</strong>.</p>',
// Stages
	'INSTALLER_CONFIGS_ADD'				=> 'Configuration ABBC3',
	'INSTALLER_BBCODES_ADD'				=> 'ABBC3 bbcodes',
));

?>